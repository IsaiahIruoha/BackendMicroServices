require('dotenv').config();
const express = require('express');
const cors = require('cors');
const url = require('url');
let bodyParser = require('body-parser');
const app = express();
const dns = require('dns');

// Basic Configuration
const port = process.env.PORT || 3000;
let counter = 1; 
const shortenedUrl = {}; 

app.use(bodyParser.urlencoded({ extended: false })); //allows parsing of form body

app.use(cors()); //for fcc testing

// Your first API endpoint
app.post('/api/shorturl/', function(req, res) {
  const hostname = new url.URL(req.body.url).hostname; //parses hostname from url
  dns.lookup(hostname, (err) => { //using hostname preforms a dns lookup
    if (err) {
      res.json({error:"invalid url"});
    } else {
      shortenedUrl[counter] = req.body.url; //if valid url, add to object with an associated key
      counter++; //increase so that the following website will be located at the next integer
      res.json({original_url:req.body.url, short_url:counter - 1});
    }
  });
});

app.get('/api/shorturl/:id', function(req, res) { //feeds the key into the object to retrieve its associated url
  res.redirect(shortenedUrl[req.params.id]);
});

//rendering
app.use('/public', express.static(`${process.cwd()}/public`));

app.get('/', function(req, res) {
  res.sendFile(process.cwd() + '/views/index.html');
});

app.listen(port, function() {
  console.log(`Listening on port ${port}`);
});
